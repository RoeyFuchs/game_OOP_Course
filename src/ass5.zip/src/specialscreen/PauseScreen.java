package specialscreen;
import behavior.Animation;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

/**
 * pause screen let the player to get a rest.
 */
public class PauseScreen implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;

    /**
     * constructor.
     * @param k - the keyboard sensor
     */
    public PauseScreen(KeyboardSensor k) {
        this.keyboard = k;
        this.stop = false;
    }

    /**
     * the pause frame.
     * @param d the surface
     */
    public void doOneFrame(DrawSurface d) {
        d.drawText(0, d.getHeight() / 2, "-paused- press space to continue", 32);
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.stop = true;
        }
    }

    /**
     * check if need to stop.
     * @return true or false
     */
    public boolean shouldStop() {
        return this.stop;
    }
}