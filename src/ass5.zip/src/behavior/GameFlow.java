package behavior;

import biuoop.KeyboardSensor;
import elements.Counter;
import levels.LevelInformation;
import specialscreen.LoseScreen;
import specialscreen.WinScreen;

import java.util.List;


/**
 * game flow receive a few game and manage the flow of the game.
 */
public class GameFlow {
    private AnimationRunner animationRunner;
    private KeyboardSensor keyboardSensor;
    private Counter score;
    private Counter numOfLives;

    /**
     * constructor.
     * @param ar animation runner
     * @param ks keyboard sensor
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks) {

        this.animationRunner = ar;
        this.keyboardSensor = ks;
        this.score = new Counter();
        this.numOfLives = new Counter();
        //7 lives is the default
        this.numOfLives.increase(7);
    }

    /**
     * run a few levels.
     * @param levels a list with the levels to play
     */
    public void runLevels(List<LevelInformation> levels) {
        for (LevelInformation levelInfo : levels) {
            GameLevel level = new GameLevel(levelInfo, this);
            level.initialize();
            while (level.getBlocksCounter().getValue() > 0 && this.numOfLives.getValue() > 0) {
                level.playOneTurn();
            }
            //lose screen
            if (this.numOfLives.getValue() == 0) {
                LoseScreen lose = new LoseScreen(this);
                this.animationRunner.run(lose);
                this.animationRunner.closeGui();
                break;
            }
        }
        //wining screen
        WinScreen win = new WinScreen(this);
        this.animationRunner.run(win);
        this.animationRunner.closeGui();
    }

    /**
     * get the animation ruuner.
     * @return the animation runner
     */
    public AnimationRunner getAnimationRunner() {
        return this.animationRunner;
    }

    /**
     * get the keyboard sensor.
     * @return the keyboard sensor
     */
    public KeyboardSensor getKeyboardSensor() {
        return this.keyboardSensor;
    }

    /**
     * get the score counter.
     * @return the score counter
     */
    public Counter getScore() {
        return this.score;
    }

    /**
     * get number of lives.
     * @return number of lives counter
     */
    public Counter getNumOfLives() {
        return this.numOfLives;
    }
}