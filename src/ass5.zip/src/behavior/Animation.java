package behavior;

import biuoop.DrawSurface;

/**
 * Animation interface.
 */
public interface Animation {
    /**
     * what to draw in a frame.
     * @param d - the surface to draw on.
     */
    void doOneFrame(DrawSurface d);

    /**
     * check in need to stop.
     * @return true or false
     */
    boolean shouldStop();
}