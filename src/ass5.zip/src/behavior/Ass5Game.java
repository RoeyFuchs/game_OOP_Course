package behavior;

import levels.LevelInformation;
import levels.DirectHitLevel;
import levels.FinalFourLevel;
import levels.Green3Level;
import levels.WideEasyLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


/**
 * try the game.
 */
public class Ass5Game {
    /**
     * initialize and play the game.
     * @param args - the levels
     */
    public static void main(String[] args) {
        AnimationRunner as = new AnimationRunner(60, 800, 600);
        GameFlow gameFlow = new GameFlow(as, as.getGui().getKeyboardSensor());
        //map of the levels and their number.
        Map<Integer, LevelInformation> map = new TreeMap<>();
        map.put(1, new DirectHitLevel());
        map.put(2, new WideEasyLevel());
        map.put(3, new Green3Level());
        map.put(4, new FinalFourLevel());

        List<LevelInformation> levels = new ArrayList<>();
        for (int i = 0; i < args.length; i++) {
            try {
                if (!(Integer.parseInt(args[i]) < 1 || Integer.parseInt(args[i]) > 4)) {
                    levels.add(map.get(Integer.parseInt(args[i])));
                } else {
                    throw new Exception();
                }
            } catch (Exception e) {
                System.out.println(args[i] + " is invalid level! continue....");
            }
        }

        gameFlow.runLevels(levels);

    }
}
