package elements;
import behavior.Collidable;
import behavior.Sprite;
import behavior.HitListener;
import behavior.HitNotifier;
import behavior.GameLevel;
import behavior.Velocity;
import biuoop.DrawSurface;
import geometry.Point;
import geometry.Rectangle;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * block class.
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private Rectangle rectangle;
    private Rectangle collisionRectangle;
    private int hitPoints = 0;
    private List<HitListener> hitListeners;
    private Color color = Color.BLACK;

    /**
     * counstructor.
     *
     * @param rectangle the rectangle of the block
     */
    public Block(Rectangle rectangle) {
        this.rectangle = rectangle;
        this.rectangle.setColor(Color.GRAY);
        this.collisionRectangle = rectangle;
        this.hitListeners = new ArrayList<>();
    }

    /**
     * counstructor.
     * @param leftTop - left point of the block
     * @param width the width of the block
     * @param hight the hight of the block
     */
    public Block(Point leftTop, double width, double hight) {
        this.rectangle = new Rectangle(leftTop, width, hight);
        this.rectangle.setColor(Color.GRAY);
        this.collisionRectangle = this.rectangle;
        this.hitListeners = new ArrayList<>();

    }
    /**
     * counstructor.
     * @param leftTop - left point of the block
     * @param width the width of the block
     * @param hight the hight of the block
     * @param hitPoints number of hit
     * @param color the color of the block
     */
    public Block(Point leftTop, double width, double hight, int hitPoints, Color color) {
        this.rectangle = new Rectangle(leftTop, width, hight);
        this.hitPoints = hitPoints;
        this.color = color;
        this.rectangle.setColor(color);
        this.collisionRectangle = this.rectangle;
        this.hitListeners = new ArrayList<>();
    }

    /**
     * set Hit points to the block.
     * @param points - number of "lives"
     */
    public void setHitPoint(int points) {
        this.hitPoints = points;
    }

    /**
     * set a collision rectangle for the block.
     * @param rec the collision rectangle
     */
    public void setCollisionRectangle(Rectangle rec) {
        this.collisionRectangle = rec;
    }

    /**
     * set a color to the block.
     * @param clr the color
     */
    public void setColor(Color clr) {
        this.color = clr;
        this.rectangle.setColor(clr);
    }

    /**
     * get the rectangle of the block.
     *
     * @return the rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.collisionRectangle;
    }


    /**
     * for now- nothing.
     */
    public void timePassed() {
        return;
    }

    /**
     * draw the block.
     * @param d surface - the surface to draw on
     */
    public void drawOn(DrawSurface d) {
        this.rectangle.drawOn(d);
    }

    /**
     * draw the number of hit points.
     * @param d - the surface to draw on
     */
    public void drawHitPoints(DrawSurface d) {
        final int fontSize = 15;
        String hitPointsToDraw;
        if (this.hitPoints <= 0) {
            hitPointsToDraw = "X";
        } else {
            hitPointsToDraw = Integer.toString(this.hitPoints);
        }
        d.setColor(Color.WHITE);
        d.drawText((int) this.rectangle.getMiddle().getX(), (int) this.rectangle.getMiddle().getY(),
                    hitPointsToDraw, fontSize);
    }

    /**
     * add the block to a gameLevel.
     * @param gameLevel the gameLevel to add the sprite to
     */
    public void addToGame(GameLevel gameLevel) {
        gameLevel.addCollidable(this);
        gameLevel.addSprite(this);
    }

    /**
     * return the velocity of an object after hit this block.
     * @param collisionPoint - where the occur happen.
     * @param currentVelocity ball velocity before the hit
     * @param hitter - the ball that hit the block
     * @return the new velocity of the ball
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        this.hitPoints -= 1;
        this.notifyHit(hitter);
        //check if the hit is on the sides of the rectangle (left or right), or on or below the rectangle (up or down)
        if (this.getCollisionRectangle().getBootomBorder().pointOnLine(collisionPoint)
                || this.getCollisionRectangle().getTopBorder().pointOnLine(collisionPoint)) {
            return new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
        }
        if (this.getCollisionRectangle().getLeftBorder().pointOnLine(collisionPoint)
            || this.getCollisionRectangle().getRightBorder().pointOnLine(collisionPoint)) {
            return new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
        }

        //if the point isn't exactly on the point
        int borderNum = this.getCollisionRectangle().findClosestBorder(collisionPoint);
        if (borderNum == 0 || borderNum == 2) {
            return new Velocity(currentVelocity.getDx(), -currentVelocity.getDy());
        } else {
            return new Velocity(-currentVelocity.getDx(), currentVelocity.getDy());
        }
    }

    /**
     * remove this block from the gameLevel.
     * @param gameLevel the gameLevel to remove from
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeCollidable(this);
        gameLevel.removeSprite(this);
    }

    @Override
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    @Override
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }

    /**
     * notify the all listeners that the block been hit.
     * @param hitter the ball that hit the block
     */
    protected void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }

    /**
     * get hit points of the block.
     * @return the hit points
     */
    public int gethitPoints() {
        return this.hitPoints;
    }

    /**
     * get the rectangle of the block.
     * @return the rectangle of the block
     */
    public Rectangle getRectangle() {
        return rectangle;
    }
}
