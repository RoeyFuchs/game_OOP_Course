/**
 * class of Line, using other class of point.
 */
public class Line {

    private Point start;
    private Point end;
    private double incline;
    private boolean isPoint;

    /**
     * constructor.
     *
     * @param start - start point of the line
     * @param end   - end point of the line
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
        this.incline = incline();
        this.isPoint = isPoint();
    }

    /**
     * constructor.
     *
     * @param x1 - the x value of the start point
     * @param y1 - the y value of the start point
     * @param x2 - the x value of the end point
     * @param y2 - the y value of the end point
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
        this.incline = incline();
        this.isPoint = isPoint();
    }

    /**
     * find the length of the line.
     *
     * @return - the length of the line
     */
    public double length() {
        double x1 = this.start.getX();
        double y1 = this.start.getY();
        double x2 = this.end.getX();
        double y2 = this.end.getY();
        //length formula
        return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    }

    /**
     * find the middle point of the line.
     *
     * @return - the middle point (as point)
     */
    public Point middle() {
        double x1 = this.start.getX();
        double y1 = this.start.getY();
        double x2 = this.end.getX();
        double y2 = this.end.getY();
        //formula to find the middle
        return new Point((x1 + x2) / 2, (y1 + y2) / 2);

    }

    /**
     * find the start point of the line.
     *
     * @return - the start point of the line (as point)
     */
    public Point start() {
        return new Point(this.start.getX(), this.start.getY());
    }

    /**
     * find the end point of the line.
     *
     * @return - the end point of the line (as point)
     */
    public Point end() {
        return new Point(this.end.getX(), this.end.getY());
    }

    /**
     * the function check if the line is intersecting with other line.
     *
     * @param other - other line
     * @return true is yes, otherwise false
     */
    public boolean isIntersecting(Line other) {
        //check if there's a meeting point
        if (intersectionWith(other) == null) {
            return false;
        }
        return true;
    }


    /**
     * the function check what the meeting point.
     *
     * @param other - other line
     * @return the meeting point (as point), or null if they are not meeting
     */
    public Point intersectionWith(Line other) {
        //check if they equals, or contain each other.
        if (this.equals(other)) {
            return null;
        }
        //if one of lines (or both) are point, there is no meeting point
        if (this.isPoint || other.isPoint) {
            return null;
        }
        double xMeeting;
        double yMeeting;
        double x1 = this.start.getX();
        double y1 = this.start.getY();
        double m1 = this.incline;
        double x2 = other.start.getX();
        double y2 = other.start.getY();
        double m2 = other.incline;
        //check individual for a spical cases of x=k and y=i
        if (m1 == 0 && (m2 == Double.POSITIVE_INFINITY || m2 == Double.NEGATIVE_INFINITY)) {
            xMeeting = x2;
            yMeeting = y1;
        } else if (m2 == 0 && (m1 == Double.POSITIVE_INFINITY || m1 == Double.NEGATIVE_INFINITY)) {
            xMeeting = x1;
            yMeeting = y2;
            //if the lines are parallel
        } else if (m1 == m2) {
            return null;
            //the regular case
        } else {
            //using a formula
            xMeeting = (-x2 * m2 + y2 + m1 * x1 - y1) / (m1 - m2);
            yMeeting = m1 * xMeeting - m1 * x1 + y1;
        }
        Point meeting = new Point(xMeeting, yMeeting);
        //check if the point is on the lines by ditance from the edge
        if ((this.start.distance(meeting) > this.length()) || (this.end.distance(meeting) > this.length())
                || (other.start.distance(meeting) > other.length()) || (other.end.distance(meeting) > other.length())) {
            return null;
        }
        return meeting;
    }

    /**
     * check if the lines are equals.
     *
     * @param other - other line
     * @return true if equals, otherwise false
     */
    public boolean equals(Line other) {
        if ((this.start.equals(other.start)) && (this.end.equals(other.end))) {
            return true;
        }
        //in a case of the points (start and end) are inverted
        if ((this.end.equals(other.start)) && (this.start.equals(other.end))) {
            return true;
        }
        return false;
    }

    /**
     * check what the incline of the line.
     *
     * @return the incline value. in a case of x=k or y=i, return zero.
     */
    public double incline() {
        return (this.start.getY() - this.end.getY()) / (this.start.getX() - this.end.getX());
    }

    /**
     * check if the line is just a point.
     * @return true if yes, otherwise false
     */
    public boolean isPoint() {
        if (this.start.equals(this.end)) {
            return true;
        }
        return false;
    }


    /**
     * find the start point.
     *
     * @return the start point
     */
    public Point getStart() {
        return this.start;
    }

    /**
     * find the end point.
     *
     * @return the end point
     */
    public Point getEnd() {
        return this.end;
    }

}