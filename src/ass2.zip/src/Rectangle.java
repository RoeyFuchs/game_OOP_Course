import biuoop.DrawSurface;
import java.awt.Color;

/**
 * Rectangle have start point (the left top corner), width, height and color.
 */
public class Rectangle {
    private Point leftTopCorner;
    private int width;
    private int height;
    private Color color = Color.BLACK;

    /**
     * constructor.
     * @param leftTopCorner - point to the left top corner
     * @param width - the width of the rectangle
     * @param height - the height of the rectangle
     * @param color - the color of the rectangle
     */
    public Rectangle(Point leftTopCorner, int width, int height, Color color) {
        this.leftTopCorner = leftTopCorner;
        this.width = width;
        this.height = height;
        this.color = color;
    }

    /**
     * cunstroctur.
     * @param leftTopCorner - point of the left top corner
     * @param rightBottomCorner - point of the right bottom corner
     * @param color - the color of the rectangle
     */
    public Rectangle(Point leftTopCorner, Point rightBottomCorner, Color color) {
        this.leftTopCorner = leftTopCorner;
        this.width = (int) rightBottomCorner.getX() - (int) leftTopCorner.getX();
        this.height = (int) rightBottomCorner.getY() - (int) leftTopCorner.getY();
        this.color = color;
    }

    /**
     * draw the rectangle on a surface.
     * @param surface - the surface to draw on
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getColor());
        surface.fillRectangle((int) leftTopCorner.getX(), (int) leftTopCorner.getY(), width, height);
    }

    /**
     * find the color of the rectangle.
     * @return the color
     */
    public java.awt.Color getColor() {
        return this.color;
    }


}
